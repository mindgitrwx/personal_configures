
# vimrc 
(Generally used for Vim editor and Intellij)

# settings.json for VSCODE 
(TODO: Sometimes settings.json text had been removed. fix it.)

# vim.ahk.exe
(notepad, powerpoint, word keybinding as vim editor . exe file - no need for any configure without removing predefined configure of VSCODE)

# HidraMouse setting 
(Logitec mouse setting)

# Surfingkeys-config-ko.js  
(google chrome vim binding) 

# Auto Text Expander setting json
(google chrome Auto Text Expander seting ) 

(TODO: make json file for import) 

# chrome://extensions/shortcuts

(여기에는 shortcut이 필요함)

markdown test

{e}^{i\pi}+1=0

$$ {e}^{i\pi}+1=0  $$

markdown - gif 도 잘 움직임 
![test.gif](test.gif)

에세이 - 컴퓨터 공학도 로서  나의 미래 
a4한바닥 - 글꼴 10 (22일 금요일 17시 plms)